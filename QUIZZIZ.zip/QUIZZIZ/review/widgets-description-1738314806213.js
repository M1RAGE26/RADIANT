	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Input_15", "1a33e59f-5cab-4786-8a06-07568050fd81"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "1a33e59f-5cab-4786-8a06-07568050fd81"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_1", "1a33e59f-5cab-4786-8a06-07568050fd81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "1a33e59f-5cab-4786-8a06-07568050fd81"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Ellipse_6", "1a33e59f-5cab-4786-8a06-07568050fd81"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "1a33e59f-5cab-4786-8a06-07568050fd81"]] = ["Previous", "s-Group_9"]; 

	widgets.descriptionMap[["s-Path_91", "1a33e59f-5cab-4786-8a06-07568050fd81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_91", "1a33e59f-5cab-4786-8a06-07568050fd81"]] = ["Previous", "s-Group_9"]; 

	widgets.descriptionMap[["s-Ellipse_6", "2cae2b26-eee2-4604-b554-1aec3a874801"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "2cae2b26-eee2-4604-b554-1aec3a874801"]] = ["Previous", "s-Group_9"]; 

	widgets.descriptionMap[["s-Path_91", "2cae2b26-eee2-4604-b554-1aec3a874801"]] = ""; 

			widgets.rootWidgetMap[["s-Path_91", "2cae2b26-eee2-4604-b554-1aec3a874801"]] = ["Previous", "s-Group_9"]; 

	widgets.descriptionMap[["s-Button_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Login Google", "s-Group_19"]; 

	widgets.descriptionMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Login Google", "s-Group_19"]; 

	widgets.descriptionMap[["s-Button_6", "dcab6c6c-e12d-47db-be31-63cfe4a3d797"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "dcab6c6c-e12d-47db-be31-63cfe4a3d797"]] = ["Basic", "s-Button_6"]; 

	widgets.descriptionMap[["s-Ellipse_6", "dcab6c6c-e12d-47db-be31-63cfe4a3d797"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "dcab6c6c-e12d-47db-be31-63cfe4a3d797"]] = ["Previous", "s-Group_9"]; 

	widgets.descriptionMap[["s-Path_91", "dcab6c6c-e12d-47db-be31-63cfe4a3d797"]] = ""; 

			widgets.rootWidgetMap[["s-Path_91", "dcab6c6c-e12d-47db-be31-63cfe4a3d797"]] = ["Previous", "s-Group_9"]; 

	