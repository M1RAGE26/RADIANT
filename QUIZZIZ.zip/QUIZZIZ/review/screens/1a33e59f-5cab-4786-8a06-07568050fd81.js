var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738314806213.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-1a33e59f-5cab-4786-8a06-07568050fd81" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 2"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/1a33e59f-5cab-4786-8a06-07568050fd81/style-1738314806213.css" />\
      <div class="freeLayout">\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Search input" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Input_15" class="text firer commentable non-processed" customid="Input"  datasizewidth="367.00px" datasizeheight="71.00px" dataX="155.00" dataY="36.00" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search"/></div></div>  </div></div></div>\
        <div id="s-Path_1" class="path firer commentable non-processed" customid="search icon"   datasizewidth="15.90px" datasizeheight="20.51px" dataX="169.68" dataY="59.67"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="15.903333333333457" height="20.511111111111063" viewBox="169.6799999999998 59.666666666666345 15.903333333333457 20.511111111111063" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-1a33e" d="M180.51017010856083 68.05571101227665 C180.51017010856083 71.13237809075214 178.56996357599883 73.63473244382588 176.18446325670195 73.63473244382588 C173.79896333652613 73.63473244382588 171.84285342592923 71.13237809075214 171.84285342592923 68.05571101227665 C171.84285342592923 64.9585337945589 173.78305995849124 62.45617738244096 176.18446325670195 62.45617738244096 C178.56996357599883 62.45617738244096 180.51017010856083 64.97904393380115 180.51017010856083 68.05571101227665 L180.51017010856083 68.05571101227665 Z M181.54388648786033 72.79377761305389 C182.29134365901604 71.41953239440883 182.68892651340408 69.73762273286484 182.68892651340408 68.05571101227665 C182.68892651340408 63.42020025532115 179.77861631544002 59.666666666666345 176.18446325670195 59.666666666666345 C172.59030999840334 59.666666666666345 169.6799999999998 63.42020025532115 169.6799999999998 68.05571101227665 C169.6799999999998 72.69122279875424 172.59030999840334 76.44475535788695 176.18446325670195 76.44475535788695 C177.48853706259465 76.44475535788695 178.7926100702452 75.91146702905809 179.87403658364937 74.96795532494225 L183.91348263088017 80.17777777777741 L185.58333333333326 78.02411020513131 L181.54388648786033 72.79377761305389 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-1a33e" fill="#A1A1A1" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="FREQUENTLY ASKED QUESTION"   datasizewidth="427.83px" datasizeheight="69.00px" dataX="16.00" dataY="178.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">FREQUENTLY ASKED QUESTIONS: </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="1. How do I start playing"   datasizewidth="551.34px" datasizeheight="525.00px" dataX="16.00" dataY="224.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">1. How do I start playing quizzes?<br />Simply sign up or log in, select a quiz category, and start answering the questions.<br /><br />2. Do I need an account to play?<br />Some quizzes may be available without an account, but creating one allows you to track your scores, compete on leaderboards, and save progress.<br /><br />3. Is the website free to use?<br />Yes, most quizzes are free. Some premium features may require a subscription.<br /><br />4. Can I pause a quiz and resume later?<br />No, once a quiz starts, you need to complete it. However, you can retake quizzes anytime.<br /><br />5. How is my score calculated?<br />Scores are based on the number of correct answers and the time taken to complete the quiz.<br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Previous - button" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="shapewrapper-s-Ellipse_6" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="58.00px" datasizeheight="58.00px" datasizewidthpx="58.0" datasizeheightpx="58.00000000000003" dataX="30.00" dataY="49.00" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_6)">\
                            <ellipse id="s-Ellipse_6" class="ellipse shape non-processed-shape manualfit firer mouseenter mouseleave click commentable non-processed" customid="Ellipse" cx="29.0" cy="29.000000000000014" rx="29.0" ry="29.000000000000014">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                            <ellipse cx="29.0" cy="29.000000000000014" rx="29.0" ry="29.000000000000014">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_6" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_6_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Path_91" class="path firer mouseenter mouseleave click commentable non-processed" customid="Chevron icon"   datasizewidth="8.44px" datasizeheight="14.73px" dataX="54.00" dataY="71.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="8.4448000000001" height="14.727083237065713" viewBox="54.0 71.0 8.4448000000001 14.727083237065713" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_91-1a33e" d="M60.7756591018514 85.44485305532241 C60.95750696503332 85.62748108916428 61.18885433476112 85.72708323706571 61.46152156400346 85.72708323706571 C62.006854677593864 85.72708323706571 62.4448000000001 85.29545050905969 62.4448000000001 84.74749749741345 C62.4448000000001 84.47355679782949 62.32916128238756 84.22455210366533 62.13906316522443 84.03356567754348 L56.35496671193154 78.35525958896929 L62.13906316522443 72.69353719383969 C62.32916128238756 72.50260042354007 62.4448000000001 72.24524324850334 62.4448000000001 71.97959067989989 C62.4448000000001 71.4316875774219 62.006854677593864 71.0 61.46152156400346 71.0 C61.18885433476112 71.0 60.95750696503332 71.09962186666758 60.7756591018514 71.28225623416023 L54.347047616253796 77.5915260195592 C54.11567923255282 77.80737751421195 54.00826319858869 78.07303008281542 54.0 78.36354771994979 C54.0 78.65413629397305 54.11567923255282 78.90314098813721 54.347047616253796 79.12728128935989 L60.7756591018514 85.44485305532241 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_91-1a33e" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;