var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738314806213.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/d12245cc-1680-458d-89dd-4f0d7fb22724/style-1738314806213.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1366.00px" datasizeheight="768.00px" dataX="-0.00" dataY="-0.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/fb35572a-1de9-4914-a95f-61bb40f1ffab.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_6" class="button multiline manualfit firer mouseenter mouseleave click commentable non-processed" customid="Secondary button"   datasizewidth="150.00px" datasizeheight="45.00px" dataX="1216.00" dataY="711.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">HELP<br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_19" class="group firer ie-background commentable non-processed" customid="Login Google button" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Button_10" class="button multiline manualfit firer mouseenter mouseleave click commentable non-processed" customid="Login with Google"   datasizewidth="190.00px" datasizeheight="46.00px" dataX="1176.00" dataY="0.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_10_0">Login with Google</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_8" class="path firer mouseenter mouseleave click commentable non-processed" customid="Shape"   datasizewidth="12.95px" datasizeheight="13.07px" dataX="1339.00" dataY="15.48"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="12.95" height="13.073207414604157" viewBox="1339.0 15.475078582763672 12.95 13.073207414604157" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_8-d1224" d="M1345.6071430183292 21.077881518671735 L1345.6071430183292 23.319003031526165 L1349.3543365907776 23.319003031526165 C1349.2033164819602 24.28081733524975 1348.2216840821918 26.139080469775916 1345.6071430183292 26.139080469775916 C1343.3512754180977 26.139080469775916 1341.5107142454176 24.29015574351162 1341.5107142454176 22.01168229006575 C1341.5107142454176 19.73320883661988 1343.3512754180977 17.884283828279578 1345.6071430183292 17.884283828279578 C1346.8908161998843 17.884283828279578 1347.7497449727957 18.425888095159465 1348.24056117268 18.89278848085647 L1350.0339287729114 17.183933531810073 C1348.8823974813815 16.11940096834602 1347.3910712270886 15.475078582763672 1345.6071430183292 15.475078582763672 C1341.9543368728534 15.475078582763672 1339.0 18.39787428075389 1339.0 22.01168229006575 C1339.0 25.625490017301605 1341.9543368728534 28.548285997367827 1345.6071430183292 28.548285997367827 C1349.4204078178661 28.548285997367827 1351.95 25.896292009703547 1351.95 22.161090052431504 C1351.95 21.731541889401942 1351.9028064275517 21.40471170403684 1351.8461734636312 21.077881518671735 L1345.6071430183292 21.077881518671735 L1345.6071430183292 21.077881518671735 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-d1224" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;