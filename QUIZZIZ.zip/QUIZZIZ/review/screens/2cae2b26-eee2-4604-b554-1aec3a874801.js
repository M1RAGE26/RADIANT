var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738314806213.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-2cae2b26-eee2-4604-b554-1aec3a874801" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 4"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/2cae2b26-eee2-4604-b554-1aec3a874801/style-1738314806213.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1366.00px" datasizeheight="768.00px" dataX="0.00" dataY="-0.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/c5e88db3-e1e0-4be1-bdfb-059508026f1d.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Previous - button" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="shapewrapper-s-Ellipse_6" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="58.00px" datasizeheight="58.00px" datasizewidthpx="58.0" datasizeheightpx="58.00000000000003" dataX="0.00" dataY="47.00" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_6)">\
                            <ellipse id="s-Ellipse_6" class="ellipse shape non-processed-shape manualfit firer mouseenter mouseleave click commentable non-processed" customid="Ellipse" cx="29.0" cy="29.000000000000014" rx="29.0" ry="29.000000000000014">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                            <ellipse cx="29.0" cy="29.000000000000014" rx="29.0" ry="29.000000000000014">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_6" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_6_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Path_91" class="path firer mouseenter mouseleave click commentable non-processed" customid="Chevron icon"   datasizewidth="8.44px" datasizeheight="14.73px" dataX="24.00" dataY="69.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="8.4448000000001" height="14.727083237065713" viewBox="24.0 69.0 8.4448000000001 14.727083237065713" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_91-2cae2" d="M30.7756591018514 83.44485305532241 C30.957506965033318 83.62748108916428 31.188854334761118 83.72708323706571 31.461521564003462 83.72708323706571 C32.006854677593864 83.72708323706571 32.4448000000001 83.29545050905969 32.4448000000001 82.74749749741345 C32.4448000000001 82.47355679782949 32.32916128238756 82.22455210366533 32.13906316522443 82.03356567754348 L26.354966711931542 76.35525958896929 L32.13906316522443 70.69353719383969 C32.32916128238756 70.50260042354007 32.4448000000001 70.24524324850334 32.4448000000001 69.97959067989989 C32.4448000000001 69.4316875774219 32.006854677593864 69.0 31.461521564003462 69.0 C31.188854334761118 69.0 30.957506965033318 69.09962186666758 30.7756591018514 69.28225623416023 L24.3470476162538 75.5915260195592 C24.115679232552818 75.80737751421195 24.008263198588697 76.07303008281542 24.0 76.36354771994979 C24.0 76.65413629397305 24.115679232552818 76.90314098813721 24.3470476162538 77.12728128935989 L30.7756591018514 83.44485305532241 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_91-2cae2" fill="#FF5722" fill-opacity="1.0" stroke-width="0.0" stroke="#FF5722" stroke-linecap="butt"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;