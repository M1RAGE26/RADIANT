var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738314806213.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-dcab6c6c-e12d-47db-be31-63cfe4a3d797" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 3"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/dcab6c6c-e12d-47db-be31-63cfe4a3d797/style-1738314806213.css" />\
      <div class="freeLayout">\
      <div id="s-Input_11" class="password firer focusin focusout commentable non-processed" customid="Input"  datasizewidth="300.00px" datasizeheight="46.52px" dataX="546.00" dataY="337.48" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder="Password"/></div></div></div></div></div>\
      <div id="s-Input_10" class="text firer focusout commentable non-processed" customid="Input"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="546.00" dataY="292.48" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Email address"/></div></div>  </div></div></div>\
      <div id="s-Button_6" class="button multiline manualfit firer mouseenter mouseleave click commentable non-processed" customid="Secondary button"   datasizewidth="150.00px" datasizeheight="45.00px" dataX="696.00" dataY="384.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">LOGIN</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="500.00px" datasizeheight="161.00px" dataX="446.00" dataY="103.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/07520a9f-cb85-45b5-a799-476ac6918c64.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Previous - button" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="shapewrapper-s-Ellipse_6" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="58.00px" datasizeheight="58.00px" datasizewidthpx="58.0" datasizeheightpx="58.00000000000003" dataX="53.00" dataY="45.00" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_6)">\
                            <ellipse id="s-Ellipse_6" class="ellipse shape non-processed-shape manualfit firer mouseenter mouseleave click commentable non-processed" customid="Ellipse" cx="29.0" cy="29.000000000000014" rx="29.0" ry="29.000000000000014">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                            <ellipse cx="29.0" cy="29.000000000000014" rx="29.0" ry="29.000000000000014">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_6" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_6_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Path_91" class="path firer mouseenter mouseleave click commentable non-processed" customid="Chevron icon"   datasizewidth="8.44px" datasizeheight="14.73px" dataX="77.00" dataY="67.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="8.4448000000001" height="14.727083237065713" viewBox="77.0 67.0 8.4448000000001 14.727083237065713" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_91-dcab6" d="M83.7756591018514 81.44485305532241 C83.95750696503332 81.62748108916428 84.18885433476112 81.72708323706571 84.46152156400346 81.72708323706571 C85.00685467759386 81.72708323706571 85.4448000000001 81.29545050905969 85.4448000000001 80.74749749741345 C85.4448000000001 80.47355679782949 85.32916128238756 80.22455210366533 85.13906316522443 80.03356567754348 L79.35496671193154 74.35525958896929 L85.13906316522443 68.69353719383969 C85.32916128238756 68.50260042354007 85.4448000000001 68.24524324850334 85.4448000000001 67.97959067989989 C85.4448000000001 67.4316875774219 85.00685467759386 67.0 84.46152156400346 67.0 C84.18885433476112 67.0 83.95750696503332 67.09962186666758 83.7756591018514 67.28225623416023 L77.3470476162538 73.5915260195592 C77.11567923255282 73.80737751421195 77.0082631985887 74.07303008281542 77.0 74.36354771994979 C77.0 74.65413629397305 77.11567923255282 74.90314098813721 77.3470476162538 75.12728128935989 L83.7756591018514 81.44485305532241 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_91-dcab6" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;