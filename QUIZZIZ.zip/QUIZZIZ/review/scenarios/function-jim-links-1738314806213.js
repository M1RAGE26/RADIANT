(function(window, undefined) {

  var jimLinks = {
    "1a33e59f-5cab-4786-8a06-07568050fd81" : {
      "Ellipse_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_91" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "2cae2b26-eee2-4604-b554-1aec3a874801" : {
      "Ellipse_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_91" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_6" : [
        "1a33e59f-5cab-4786-8a06-07568050fd81"
      ],
      "Button_10" : [
        "dcab6c6c-e12d-47db-be31-63cfe4a3d797"
      ],
      "Path_8" : [
        "dcab6c6c-e12d-47db-be31-63cfe4a3d797"
      ]
    },
    "dcab6c6c-e12d-47db-be31-63cfe4a3d797" : {
      "Button_6" : [
        "2cae2b26-eee2-4604-b554-1aec3a874801"
      ],
      "Ellipse_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_91" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);